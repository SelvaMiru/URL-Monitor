package com.accenture.splunk.operations;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.Certificate;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.URLMonitorBuilder;

public class MiscellaneousOps {
	
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(MiscellaneousOps.class);
	
	/**
	 * Function to get the status of the Application URL via its response
	 * <br/>code
	 * @param responseCode
	 * @return <b>boolean value</b> (true if response code is between 200 and 400, else false)
	 */
	protected boolean getUrlStatus(int responseCode) {
		return (responseCode >= 200 && responseCode < 400)? true : false;
	}
	
	/**
	 * Function to format the URL to only its domain name
	 * @param url (URL)
	 * @return (<b>URL</b> object)
	 * @throws MalformedURLException
	 * @throws StringIndexOutOfBoundsException
	 */
	protected URL formatUrl(URL url) throws MalformedURLException, StringIndexOutOfBoundsException {
		String urlString = url.toString();
		int index = urlString.indexOf('/');
		int counter = 0;
		while (urlString.length() > index) {
			if(urlString.charAt(index++) == '/') {
				counter++;
			}
			if (counter == 3) break;
		}
		return new URL(urlString.substring(0, index));		
	}
	
	/**
	 * 
	 * @param url
	 * @return
	 * @throws IOException
	 */
	protected Certificate[] getCertificate(URL url) throws IOException {
		url = new URL(url.getProtocol()+"://"+url.getHost());
		HttpsURLConnection httpsConnection = (HttpsURLConnection)url.openConnection();
		httpsConnection.connect();
		return (httpsConnection.getServerCertificates());
	}
	
	/**
	 * 
	 * @param appName
	 * @param url
	 * @param responseCode
	 * @param responseMessage
	 * @param responseTime
	 * @param certDetails
	 * @param certExpiryDate
	 * @param status
	 * @param lastChecked
	 * @return
	 */
	protected URLMonitorBuilder buildMonitor(String appName, URL url, int responseCode, String responseMessage,
			long responseTime, Certificate[] certDetails, String certExpiryDate, String status, String lastChecked,
			String sslVersion) {
		
		log.debug("build Complete");
		
		return new URLMonitorBuilder.Builder()
					.setAppName(appName)
					.setUrl(url)
					.setResponseCode(responseCode)
					.setResponseMessage(responseMessage)
					.setResponseTime(responseTime)
					.setCertDetails(certDetails)
					.setCertExpiryDate(certExpiryDate)
					.setStatus(status)
					.setLastChecked(lastChecked)
					.setSslVersion(sslVersion)
					.build();		
		
	}
	
	/**
	 * 
	 * @param longMessage
	 * @return
	 */
	protected String getMessage(String longMessage) {
		String[] message = longMessage.split(":");
		return message[message.length - 1].trim();
	}

}
