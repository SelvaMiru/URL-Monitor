package com.accenture.splunk.URL_Monitor;

/**
 * Class storing the constants for URL-SSL Monitoring and its scripts.<br/>
 * Will become obsolete on implementation of JAXB feature<center>OR</center>
 * <tt>URLSSL.properties</tt> file implementation
 * @author sayon.kumar.ghosh
 *
 */
public class MonitoringConstants {
	
	/** contains the threshold value for Connection timeout */
	protected final static int CONNECTION_TIMEOUT_THRESHOLD = 20000;
		
	/** contains the threshold value for Read timeout */
	protected final static int READ_TIMEOUT_THRESHOLD = 50000;
	
	/** contains the headers for the generate CSV file (output file) */
	protected final static String ATTRIBUTES = "APPLICATION_NAME,URL,STATUS,RESPONSE_CODE,RESPONSE_TIME,RESPONSE_MESSAGE,CERT_EXPIRY_DATE,LAST_CHECKED,SSL_VERSION";
	
	/** contains the format in which date is printed in the output file, for both LAST_CHECKED and CERT_EXPIRY_DATE */
	protected final static String SIMPLE_DATE_FORMAT = "EEE dd-MMM-yyyy 'at' HH:mm:ss z";
	
	/** contains the path to properties file */
	protected final static String PATH_TO_PROPERTIES = "URLSSL.properties";
	
	/** contains the path to properties file in Ghosh's System */
	protected final static String PATH_TO_PROPERTIES_DEV_SYSTEM = "C:/Users/sayon.kumar.ghosh/workspace/urlmonitor/src/main/java/resources/URLSSL.properties";
	
	/** contains the path to log4j.properties */
	protected final static String PATH_TO_LOG4J_PROPERTIES = "log4j.properties";
	
}
