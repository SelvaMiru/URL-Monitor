package com.accenture.splunk.builders;

/**
 * The builder class for Properties, i.e., <br/>
 * 1. Connection Timeout Threshold,<br/>
 * 2. Read Timeout Threshold,<br/>
 * 3. Input File Location,<br/>
 * 4. Output File Location,<br/>
 * 5. Path to Log4j Properties,<br/>
 * 6. Attributes (output file column names),<br/>
 * 7. Date Format,<br/>
 * 8. Hostname and<br/>
 * 9. System O.S.
 * @author sayon.kumar.ghosh
 *
 */
public class PropertiesBuilder {
	
	/** stores the connection timeout threshold value */
	int connectTimeoutThreshold;
	
	/**	stores the read timeout threshold value */
	int readTimeoutThreshold;
	
	/** stores the input file location */
	String inputFileLocation;
	
	/** stores the output file location */
	String outputFileLocation;
	
	/** stores the path to Log4j properties file */
	String pathToLog4jProps;
	
	/** stores the headers (column names) for the output file */
	String attributes;
	
	/** stores the date format */
	String simpleDateFormat;
	
	/** stores the hostname of the system its running on */
	String hostName;
	
	/** stores the OS name and version for the host system */
	String system;
	
	/**
	 * constructor for the PropertiesBuilder class, taking in Builder object values as parameters
	 * @param builder
	 */
	public PropertiesBuilder(Builder builder) {
		this.connectTimeoutThreshold = builder.connectTimeoutThreshold;
		this.readTimeoutThreshold = builder.readTimeoutThreshold;
		this.inputFileLocation = builder.inputFileLocation;
		this.outputFileLocation = builder.outputFileLocation;
		this.pathToLog4jProps = builder.pathToLog4jProps;
		this.attributes = builder.attributes;
		this.simpleDateFormat = builder.simpleDateFormat;
		this.hostName = builder.hostName;
		this.system = builder.system;
	}
	
	/**
	 * getter function for connection timeout threshold
	 * @return connectTimeoutThreshold (int)
	 */
	public int getConnectTimeoutThreshold() {
		return connectTimeoutThreshold;
	}

	/**
	 * getter function for read timeout threshold
	 * @return readTimeoutThreshold (int)
	 */
	public int getReadTimeoutThreshold() {
		return readTimeoutThreshold;
	}

	/**
	 * getter function for input file location path
	 * @return inputFileLocation (String)
	 */
	public String getInputFileLocation() {
		return inputFileLocation;
	}

	/**
	 * getter function for output file location
	 * @return outputFileLocation (String)
	 */
	public String getOutputFileLocation() {
		return outputFileLocation;
	}
	
	/**
	 * getter function for path to Log4j properties
	 * @return pathToLog4jProps (String)
	 */
	public String getPathToLog4jProps() {
		return pathToLog4jProps;
	}

	/**
	 * getter function for attributes (column names) for the output file
	 * @return attributes (String)
	 */
	public String getAttributes() {
		return attributes;
	}
	
	/**
	 * getter function for date format
	 * @return simpleDateFormat (String)
	 */
	public String getSimpleDateFormat() {
		return simpleDateFormat;
	}
	
	/**
	 * getter function for host name
	 * @return hostName (String)
	 */
	public String getHostName() {
		return hostName;
	}
	
	/**
	 * getter function for system OS and OS version
	 * @return system (String)
	 */
	public String getSystem() {
		return system;
	}
	
	/**
	 * setter function for connetion timeout threshold
	 * @param connectTimeoutThreshold
	 */
	public void setConnectTimeoutThreshold(int connectTimeoutThreshold) {
		this.connectTimeoutThreshold = connectTimeoutThreshold;
	}

	/**
	 * setter function for read timeout threshold
	 * @param readTimeoutThreshold
	 */
	public void setReadTimeoutThreshold(int readTimeoutThreshold) {
		this.readTimeoutThreshold = readTimeoutThreshold;
	}

	/**
	 * setter function for input file location
	 * @param inputFileLocation
	 */
	public void setInputFileLocation(String inputFileLocation) {
		this.inputFileLocation = inputFileLocation;
	}

	/**
	 * setter function for output file location
	 * @param outputFileLocation
	 */
	public void setOutputFileLocation(String outputFileLocation) {
		this.outputFileLocation = outputFileLocation;
	}

	/**
	 * setter function for path to Log4j properties file
	 * @param pathToLog4jProps
	 */
	public void setPathToLog4jProps(String pathToLog4jProps) {
		this.pathToLog4jProps = pathToLog4jProps;
	}

	/**
	 * setter function for attributes
	 * @param attributes
	 */
	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	
	/**
	 * setter function for date format
	 * @param simpleDateFormat
	 */
	public void setSimpleDateFormat(String simpleDateFormat) {
		this.simpleDateFormat = simpleDateFormat;
	}
	
	/**
	 * setter function for host name
	 * @param osName
	 */
	public void setHostName(String osName) {
		this.hostName = osName;
	}
	
	/**
	 * setter function for system 
	 * @param system
	 */
	public void setSystem(String system) {
		this.system = system;		
	}
	/**
	 * overridden toString() method for {@link PropertiesBuilder} class
	 * @return String
	 */
	@Override
	public String toString() {
		return " {"
				+" connectTimeoutThreshold= "+getConnectTimeoutThreshold()
				+", readTimeoutThreshold= "+getReadTimeoutThreshold()
				+", inputFileLocation= "+getInputFileLocation()
				+", outputFileLocation= "+getOutputFileLocation()
				+", pathToLog4jProps= "+getPathToLog4jProps()
				+", attributes= "+getAttributes()
				+", simpleDateFormat= "+getSimpleDateFormat()
				+", hostName= "+getHostName()
				+", system= "+getSystem()
				+" }";
	}

	/**
	 * Builder inner class for {@link PropertiesBuilder}, to facilitate setter functions for {@link PropertiesBuilder}
	 * variables and build method, follows Builder Design Pattern
	 * @author sayon.kumar.ghosh
	 *
	 */
	public static class Builder {
		
		/** stores the connection timeout threshold */
		private int connectTimeoutThreshold;
		
		/** stores the read timeout threshold */
		private int readTimeoutThreshold;
		
		/** stores the input file location */
		private String inputFileLocation;
		
		/** stores the output file location */
		private String outputFileLocation;
		
		/** stores the path to log4j properties file */
		private String pathToLog4jProps;
		
		/** stores the column names (headers) for the output file */
		private String attributes;
		
		/** stores the date format */
		private String simpleDateFormat;
		
		/** stores the host name for the system */
		private String hostName;
		
		/** stores the system OS and the OS version */
		private String system;
		
		/**
		 * setter method for system
		 * @param system
		 * @return (Builder object)
		 */
		public Builder setSystem(String system) {
			this.system = system;
			return this;
		}
		
		/**
		 * setter method for connection timeout threshold
		 * @param connectTimeoutThreshold
		 * @return (Builder object)
		 */
		public Builder setConnectTimeoutThreshold(int connectTimeoutThreshold) {
			this.connectTimeoutThreshold = connectTimeoutThreshold;
			return this;
		}
		
		/**
		 * setter method for read timeout threshold
		 * @param readTimeoutThreshold
		 * @return (Builder object)
		 */
		public Builder setReadTimeoutThreshold(int readTimeoutThreshold) {
			this.readTimeoutThreshold = readTimeoutThreshold;
			return this;
		}
		
		/**
		 * setter method for input file location
		 * @param inputFileLocation
		 * @return (Builder object)
		 */
		public Builder setInputFileLocation(String inputFileLocation) {
			this.inputFileLocation = inputFileLocation;
			return this;
		}
		
		/**
		 * setter method for output file location
		 * @param outputFileLocation
		 * @return (Builder object)
		 */
		public Builder setOutputFileLocation(String outputFileLocation) {
			this.outputFileLocation = outputFileLocation;
			return this;			
		}
		
		/**
		 * setter method for path to log4j properties file
		 * @param pathToLog4jProps
		 * @return (Builder object)
		 */
		public Builder setPathToLog4jProps(String pathToLog4jProps) {
			this.pathToLog4jProps = pathToLog4jProps;
			return this;
		}
		
		/**
		 * setter method for attributes
		 * @param attributes
		 * @return (Builder object)
		 */
		public Builder setAttributes(String attributes) {
			this.attributes = attributes;
			return this;
		}
		
		/**
		 * setter method for date format
		 * @param simpleDateFormat
		 * @return (Builder object)
		 */
		public Builder setSimpleDateFormat(String simpleDateFormat) {
			this.simpleDateFormat = simpleDateFormat;
			return this;
		}
		
		/**
		 * build method for Builder inner class for PropertiesBuilder class,<br/>
		 * for building objects of PropertiesBuilder, i.e., Connection Timeout Threshold,<br/>
		 * Read Timeout Threshold, path to log4j Properties, Input File Location,<br/>
		 * Input File Location, Attributes, Simple Date Format, Hostname and System
		 * @return (PropertiesBuilder object)
		 */
		public PropertiesBuilder build() {
			return new PropertiesBuilder(this);
		}
		
		/**
		 * setter method for OS Name
		 * @param osName
		 * @return (Builder object)
		 */
		public Builder setHostName(String osName) {
			this.hostName = osName;
			return this;
		}
		
		/**
		 * Overridden toString() method for PropertiesBuilder$Builder
		 * @return (String)
		 */
		@Override
		public String toString() {
			return "{ "
					+" connectTimeoutThreshold= "+this.connectTimeoutThreshold
					+", readTimeoutThreshold= "+this.readTimeoutThreshold
					+", inputFileLocation= "+this.inputFileLocation
					+", outputFileLocation= "+this.outputFileLocation
					+", pathToLog4jProps= "+this.pathToLog4jProps
					+", attributes= "+this.attributes
					+", simpleDateFormat= "+this.simpleDateFormat
					+", hostName= "+this.hostName
					+", system= "+this.system
					+" }";
		}
		
	}

}
