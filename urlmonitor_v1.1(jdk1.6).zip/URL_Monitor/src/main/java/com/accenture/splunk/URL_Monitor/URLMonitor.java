package com.accenture.splunk.URL_Monitor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.InputDataBuilder;
import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.builders.URLMonitorBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;
import com.accenture.splunk.fileops.FileInput;
import com.accenture.splunk.fileops.FileOutput;
import com.accenture.splunk.operations.ConnectionDetails;

/**
 * Class <b>UrlSslMonitoring</b>
 * <br/> For monitoring URL status for AT&T Gemini Applications,
 * <br/> as well as the instances for the applications
 * @author sayon.kumar.ghosh (sg480b)
 * 
 */
public class URLMonitor {
	
	/** {@link PropertiesBuilder} object */
	private static PropertiesBuilder props;
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(URLMonitor.class);
	
	public static void main(String[] args) {
				
		/** TODO: Configure path to urlssl.properties file here */
		props = PropertiesStorage.setProperties((args.length!=0)? args[0] : MonitoringConstants.PATH_TO_PROPERTIES);
		
		/** TODO: Configure path to log4j.properties file here: {@link PropertiesStorage}:45 */
		/*PropertyConfigurator.configure(MonitoringConstants.PATH_TO_LOG4J_PROPS);*//** truncated */		
		PropertyConfigurator.configure(props.getPathToLog4jProps());		
        
		/** Variable declaration column */
		FileInput fileInput = new FileInput();
		FileOutput fileOutput = new FileOutput();
		ConnectionDetails connDetails = new ConnectionDetails();
		ArrayList<InputDataBuilder> inputDataList = new ArrayList<InputDataBuilder>();
		ArrayList<URLMonitorBuilder> monitorBuilderList = new ArrayList<URLMonitorBuilder>();
		boolean scriptExecutionStatus = false;
		Calendar cal = Calendar.getInstance();
		/*SimpleDateFormat sdf = new SimpleDateFormat(MonitoringConstants.SIMPLE_DATE_FORMAT);*//** truncated */
		SimpleDateFormat sdf = new SimpleDateFormat(props.getSimpleDateFormat());
		Date startTime = cal.getTime();
        Calendar cal2;
        Date stopTime;
        long millis;
        String executionTime = null;
		
        log.info("Script execution began on {}", sdf.format(startTime));
		
        try {
			
			log.info("URL testing begins ...");
			inputDataList = fileInput.readInputsCsv(props);
			for(int i = 0; i < inputDataList.size(); i++) {
				monitorBuilderList.add(connDetails.checkUrlSsl(inputDataList.get(i), props));
			}
			
			log.info("URLs Tested Successfully, generating output file ...");
			scriptExecutionStatus = fileOutput.printOutputCsv(monitorBuilderList, props);
			
			log.info("Script Executed {}", scriptExecutionStatus? "Successfully":"Unsuccessfully");
			
		} catch(SplunkExceptions se) {
			
			log.error("Execution Failed:: \n\t\t\tCause: {}; \n\t\t\tMessage: {}", se, se.getMessage());			
			se.printStackTrace();
		}
		cal2 = Calendar.getInstance();
		stopTime = cal2.getTime();
		millis = stopTime.getTime()-startTime.getTime();
		executionTime = String.format("%d minute(s) and %d second(s)", 
			    			TimeUnit.MILLISECONDS.toMinutes(millis),
		    				TimeUnit.MILLISECONDS.toSeconds(millis) - 
		    				TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))
						);
		log.info("Script finished execution on {}", sdf.format(stopTime));
		log.info("Script execution duration: {}.", executionTime);
		
	}

}
