package com.accenture.splunk.fileops;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.InputDataBuilder;
import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;

public class FileInput {

	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(FileInput.class);

	public FileInput() {
		// TODO: constructor
	}

	/**
	 * Reads the CSV file containing the list of Applications along with their
	 * URLs
	 * 
	 * @return ArrayList<{@link InputDataBuilder}> object
	 * @throws SplunkExceptions
	 */
	public ArrayList<InputDataBuilder> readInputsCsv(PropertiesBuilder props)
			throws SplunkExceptions {

		/* File inputFile = new File(MonitoringConstants.INPUT_FILE_LOCATION); */
		File inputFile = new File(props.getInputFileLocation());
		String line = null;
		String[] fields = null;
		InputDataBuilder inputData = null;
		ArrayList<InputDataBuilder> inputDataList = new ArrayList<InputDataBuilder>();
		String appName = null;
		URL url = null;
		Scanner scanner = null;

		if (!inputFile.exists()) {
			log.error("Unable to retrieve input file at location: {}.",
					inputFile.getAbsolutePath());
			throw new SplunkExceptions(
					"Input File not found in Location: "
							+ inputFile.getAbsolutePath()
							+ "\n Please add the input file in the above location to proceed ...");
		} else {
			try {
				scanner = new Scanner(inputFile);
				while (scanner.hasNext()) {
					line = scanner.nextLine();
					fields = line.split(",");
					if (fields[1].equalsIgnoreCase("URL")) {
						continue;
					} else {
						appName = fields[0];
						try {
							url = new URL(fields[1]);
						} catch (MalformedURLException e) {
							throw new SplunkExceptions("Invalid URL: "
									+ fields[1], e);
						}

						inputData = new InputDataBuilder.Builder()
								.setAppName(appName).setUrl(url).build();
						inputDataList.add(inputData);
					}

				}

			} catch (FileNotFoundException e) {
				log.error("Input File not found in Location: {}.",
						inputFile.getAbsolutePath());
				throw new SplunkExceptions(
						"Input File not found in Location: "
								+ inputFile.getAbsolutePath()
								+ "\n Please add the input file in the above location to proceed ...",
						e);
			} catch (SplunkExceptions e) {
				log.error("Invalid URL found in input file: {}.", fields[1]);
				throw new SplunkExceptions(
						"Invalid URL found in input file ...\n\t "
								+ e.getMessage()
								+ "\n Failed in reading input file. Please correct the error and try again ...",
						e);
			}
			finally {
				scanner.close();
			}

			log.info("Input File read successfully.");
			return inputDataList;
		}

	}
}
