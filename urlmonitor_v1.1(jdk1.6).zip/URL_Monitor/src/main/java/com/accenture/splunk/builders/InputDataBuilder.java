package com.accenture.splunk.builders;

import java.net.URL;
/**
 * Builder class for input fields,i.e.,<br/>1. Application Name and<br/>2. URL
 * @author sayon.kumar.ghosh
 *
 */
public class InputDataBuilder {
	
	/** stores the application name for the URL */
	String appName;
	
	/** stores the URL */
	URL url;
	
	/** constructor for InputDataBuilder class, taking in parameters as a Builder object  
	 * @param builder
	 */
	public InputDataBuilder(Builder builder) {
		this.appName = builder.appName;
		this.url = builder.url;
	}	
	
	/**
	 * getter function for Application Name
	 * @return appName (String)
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * getter function for URL
	 * @return url (URL object)
	 */
	public URL getUrl() {
		return url;
	}

	/**
	 * setter function for Application Name
	 * @param appName (String)
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * setter function for URL
	 * @param url (URL)
	 */
	public void setUrl(URL url) {
		this.url = url;
	}
	
	/**
	 * Overriden toString() method for InputDataBuilder Class
	 * @return (String)
	 */
	@Override
	public String toString() {
		return " {"
				+" appName= "+getAppName()
				+", url= "+getUrl()
				+" } ";
	}

	/**
	 * Builder inner class for InputDataBuilder, to facilitate the setter functions for InputDataBuilder variables and build
	 * method, follows Builder Design Pattern
	 * @author sayon.kumar.ghosh
	 *
	 */
	public static class Builder {
		
		/** stores the Application Name for the URL */
		private String appName;
		/** store the URL of the Application */
		private URL url;
		
		/**
		 * setter method for Application Name for the application;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param appName
		 * @return (Builder object)
		 */
		public Builder setAppName(String appName) {
			this.appName = appName;
			return this;
		}
		
		/**
		 * setter method for URL for the application;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param url
		 * @return (Builder object)
		 */
		public Builder setUrl(URL url) {
			this.url = url;
			return this;
		}
		
		/**
		 * build() method for Builder inner class of InputDataBuilder class, for building the objects of 
		 * InputDataBuilder, i.e., appName and url, for Application Name and URL for any application
		 * @return (InputDataBuilder object)
		 */
		public InputDataBuilder build() {
			return new InputDataBuilder(this);
		}
		
		/**
		 * Overridden toString() method for InputDataBuilder$Builder class
		 * @return (String)
		 */
		@Override
		public String toString() {
			return " {"
					+" appName= "+this.appName
					+", url= "+this.url
					+" } ";
		}
		
	}

}
