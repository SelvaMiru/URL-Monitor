package com.accenture.splunk.operations;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.InputDataBuilder;
import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.builders.URLMonitorBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;

public class ConnectionDetails {
	
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(ConnectionDetails.class);
	
	/**
	 * Pings the URL for every Application URL and updates the supported data in an 
	 * <br/>{@link URLMonitorBuilder} object which in turn is used to 
	 * <br/>generate the output (.csv) file.
	 * @param inputData (an {@link InputDataBuilder} object)
	 * @return {@link URLMonitorBuilder} object
	 * @throws SplunkExceptions
	 */
	public URLMonitorBuilder checkUrlSsl(InputDataBuilder inputData,
			PropertiesBuilder props) throws SplunkExceptions {
		
		long startTime = 0;
		HttpsURLConnection httpsConnection;
		HttpURLConnection httpConnection;
		URL url = inputData.getUrl();
		String appName = inputData.getAppName();
		int connectTimeout = props.getConnectTimeoutThreshold();
		int readTimeout = props.getReadTimeoutThreshold();
		int responseCode = 0;
		long responseTime = 0;
		String responseMessage = null;
		String sslExpiryDate = null;
		String sslVersion = null;
		Certificate[] certificate = null;
		boolean status = false; 
		Calendar cal = Calendar.getInstance();
		MiscellaneousOps miscOps = new MiscellaneousOps();
		WGETOps wgetOps = new WGETOps();
		CURLOps curlOps = new CURLOps();
		/*SimpleDateFormat sdf = new SimpleDateFormat(MonitoringConstants.SIMPLE_DATE_FORMAT);*/
		SimpleDateFormat sdf = new SimpleDateFormat(props.getSimpleDateFormat());
        String lastChecked = sdf.format(cal.getTime());
        String[] outputs = null;
        
/**------------------------------------------- 1st Attempt ----------------------------------------------------**/
        
        log.info("1st attempt for URL: {}", url.toString());
		try {
			if(url.getProtocol().equalsIgnoreCase("https")) {
				httpsConnection = (HttpsURLConnection)url.openConnection();				
				httpsConnection.setConnectTimeout(connectTimeout);
				httpsConnection.setReadTimeout(readTimeout);
				httpsConnection.setRequestMethod("HEAD");
				startTime = System.currentTimeMillis();
				responseCode = httpsConnection.getResponseCode();
				responseMessage = httpsConnection.getResponseMessage();
				status = miscOps.getUrlStatus(responseCode);
				if(status) {
					//startTime = System.currentTimeMillis();
					httpsConnection.connect();
					httpsConnection.getInputStream();
					responseTime = System.currentTimeMillis() - startTime;
					/*certificate = httpsConnection.getServerCertificates();*/
					certificate = miscOps.getCertificate(url);
					sslExpiryDate = sdf.format(((X509Certificate)certificate[0]).getNotAfter());
					sslVersion = ((X509Certificate)certificate[0]).getVersion()+"";
				} else {
					responseTime = System.currentTimeMillis() - startTime;
					certificate = null;
					sslExpiryDate = null;
					sslVersion = null;
				}
			} else {
				httpConnection = (HttpURLConnection)url.openConnection();
				httpConnection.setConnectTimeout(connectTimeout);
				httpConnection.setReadTimeout(readTimeout);
				httpConnection.setRequestMethod("HEAD");
				startTime = System.currentTimeMillis();
				responseCode = httpConnection.getResponseCode();
				responseMessage = httpConnection.getResponseMessage();
				status = miscOps.getUrlStatus(responseCode);
				if(status) {
					httpConnection.connect();
					httpConnection.getInputStream();
				}
				responseTime = System.currentTimeMillis() - startTime;					
				sslExpiryDate = null;
				certificate = null;
				sslVersion = null;
			}
			log.info("Response Recorded: {}, URL: {} with Expiry: {}", appName, url, sslExpiryDate);
			/*System.out.println("Response Recorded: "+appName+", URL: "+url+" with expiry: "+sslExpiryDate);*/
		} catch (SSLPeerUnverifiedException spue) {
			/*throw new SplunkExceptions("SSL Peer is Unverified", spue);*/
			/*System.err.println("Exception: "+spue.getMessage()+" for "+appName+" URL: "+url.toString());*/
			log.error("Exception: {} for {}, URL: {}", spue.getMessage(), appName, url);
			responseMessage = (responseMessage!=null)? responseMessage: miscOps.getMessage(spue.getMessage());
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			
		} catch (ProtocolException pe) {
			/*throw new SplunkExceptions("Invalid Protocol OR Protocol Exception Occurred; Request Method: \"HEAD\"", pe);*/
			/*System.err.println("Exception: "+pe.getMessage()+" for "+appName+" URL: "+url.toString());*/
			log.error("Exception: {} for {}, URL: {}", pe.getMessage(), appName, url);
			responseMessage = (responseMessage!=null)? responseMessage: miscOps.getMessage(pe.getMessage());
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			
		} catch (IOException ioe) {
			/*throw new SplunkExceptions("Failed to open connection to URL: "+url.toString(), ioe);*/
			/*System.err.println("Exception: "+ioe.getMessage()+" for "+appName+" URL: "+url.toString());*/
			log.error("Exception: {} for {}, URL: {}", ioe.getMessage(), appName, url);
			responseMessage = (responseMessage!=null)? responseMessage: miscOps.getMessage(ioe.getMessage());
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			
		}		
		
/**-------------------------------------------- 2nd Attempt -------------------------------------------------------**/
		
		if(!status) {
			log.info("2nd attempt for URL: {}", url.toString());
			try {
/***************************************************WGET*************************************************************/
				outputs = wgetOps.retryConnectionWithWGET(miscOps.formatUrl(url), props);
				if(outputs != null) {
					if(outputs.length > 2) {
						responseCode = Integer.parseInt(outputs[1]);
						responseTime = (long) (Double.parseDouble(outputs[2]) * 1000);
						responseMessage = outputs[3];
						status = miscOps.getUrlStatus(responseCode);
					}
					certificate = null;
					sslExpiryDate = null;
					sslVersion = null;
					lastChecked = sdf.format(cal.getTime());
				}
				
/**************************************************WGET**************************************************************/
				if(status) {
					log.info("Successfully connected to {}", url.toString());					
				} else {
							
/**-------------------------------------- 3rd and final Attempt ---------------------------------------------------**/
							
					log.error("Reconnection attempt unsuccessful to {}", url.toString());
					log.warn("3rd and final attempt for URL: {}", url.toString());
/*************************************************CURL****************************************************************/
					outputs = curlOps.retryConnectionWithCURL(miscOps.formatUrl(url), props);
					if(outputs != null) {
						if(outputs.length > 5 && outputs[1].matches("[-+]?\\d*\\.?\\d+")) {
							responseCode = Integer.parseInt(outputs[1]);
							responseMessage = outputs[2];
							status = miscOps.getUrlStatus(responseCode);
							if(outputs[outputs.length - 1].matches("[-+]?\\d*\\.?\\d+")) {
								responseTime = (long) (Double.parseDouble(outputs[outputs.length - 1])*1000);
							} else {
								responseTime = 0L;
							}
						}
					} else {
						log.error("Re-reconnection attempt unsuccessful to {}", url.toString());
						log.warn("No more attempts remain for {}, considered DOWN", url.toString());
					}
/*************************************************CURL****************************************************************/
					certificate = null;
					sslExpiryDate = null;
					sslVersion = null;
					lastChecked = sdf.format(cal.getTime());				
				}
			} catch (MalformedURLException mue) {
				log.error("Error in formatted URL: {}, Exception: {}", mue.getMessage(), mue);
				/*System.err.println("Exception caught while formatting URL: "+mue);*/
			} catch (StringIndexOutOfBoundsException sioobe) {
				log.error("Error in formatting URL: {}", sioobe.getMessage());
				/*System.err.println("Exception caught while formatting URL: "+sioobe);*/
			}
		}
		
		return miscOps.buildMonitor(appName, url, responseCode, responseMessage, responseTime, certificate, sslExpiryDate,
				status? "UP":"DOWN", lastChecked, sslVersion);
			
	}

}
