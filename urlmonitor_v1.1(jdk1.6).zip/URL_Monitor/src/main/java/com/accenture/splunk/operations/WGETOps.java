package com.accenture.splunk.operations;

import java.net.URL;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.PropertiesBuilder;

public class WGETOps {
	
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(WGETOps.class);

	protected String[] retryConnectionWithWGET(URL url, PropertiesBuilder props) {

		String[] outputs = null;
		Process process = null;
		Scanner scanner = null;
		int exitValue = 0;
		int splits = 0;
		String temp = "";
		/**
		 * commandUnixWGET = time -p wget --spider --connect-timeout=20
		 * read-timeout=50 --no-check-certificate --server-response --quiet {}
		 * 2>&1 | egrep 'HTTP/|real'
		 */
		String[] commandUnixWGET = {
				"/bin/sh",
				"-c",
				"time -p wget --spider --connect-timeout="
						+ (props.getConnectTimeoutThreshold() / 1000)
						+ " --read-timeout="
						+ (props.getReadTimeoutThreshold() / 1000)
						+ " --no-check-certificate --server-response --quiet \""
						+ url + "\" 2>&1 | egrep 'HTTP/|real'" };
		@SuppressWarnings("unused")
		String[] commandWindows = {};

		try {
			if (props.getSystem().equalsIgnoreCase("sunos")
					|| props.getSystem().equalsIgnoreCase("linux")) {

				process = Runtime.getRuntime().exec(commandUnixWGET);
				scanner = new Scanner(process.getInputStream());
				while (scanner.hasNext()) {
					temp += scanner.nextLine() + " ";
				}
				process.waitFor();
				exitValue = process.exitValue();
				if (exitValue == 0) {
					outputs = temp.split(" ");
					splits = outputs.length;
					if (splits > 2) {
						log.info(
								"Re-ReConnection attempt successfull with URL {}",
								url.toString());
						temp = "";
						outputs[0] = outputs[2]; /*
												 * assigning http(s) version to
												 * outputs[0] for convenience
												 */
						outputs[1] = outputs[3]; /*
												 * assigning response code to
												 * outputs[1]
												 */
						outputs[2] = outputs[splits - 1]; /*
														 * assigning response
														 * time to outputs[1]
														 */
						for (int i = 4; !outputs[i].equalsIgnoreCase("real"); i++) {
							temp += outputs[i] + " ";
						}
						outputs[3] = temp; /*
											 * assigning response message to
											 * outputs[3]
											 */
					} else {
						log.error("Connection to URL {} refused",
								url.toString());
					}
				} else {
					log.error("Connection attempt failed for URL {}",
							url.toString());
				}
				scanner.close();
			} else if (props.getSystem().equalsIgnoreCase("windows")) {
				/* process = Runtime.getRuntime().exec(commandWindows); */
				// scoped for later release ...
			} else
				;

		} catch (Exception ioe) {
			log.error(
					"Connection Process failed for URL: {} with exception: {}",
					url.toString(), ioe.getMessage());
		}

		return outputs;

	}

}
