package com.accenture.splunk.fileops;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.builders.URLMonitorBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;

public class FileOutput {	
	
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(FileOutput.class);
	
	public FileOutput() {
		//TODO: contructor
	}
	
	/**
	 * Populates the urlPingResults.csv (output file) with the ArrayList<{@link URLMonitorBuilder}>
	 * @param monitorBuilderList (an ArrayList of {@link URLMonitorBuilder} object)
	 * @param props (a {@link PropertiesBuilder} object)
	 * @return <b>boolean</b> object
	 * @throws SplunkExceptions
	 */
	public boolean printOutputCsv(ArrayList<URLMonitorBuilder> monitorBuilderList,
			PropertiesBuilder props) throws SplunkExceptions {
		
		/*File outputFile = new File(MonitoringConstants.OUTPUT_FILE_LOCATION);*/
		File outputFile = new File(props.getOutputFileLocation());
		FileWriter writer = null;
		
		try {
			log.info("Checking if output file exists ...");
			if(!outputFile.exists()) {
				log.info("Output file does not exist.");
				log.info("Creating output file ...");
				outputFile.getParentFile().mkdirs();
				outputFile.createNewFile();
				log.info("Output file created successfully at location {}.", outputFile.getAbsolutePath());
			}
		} catch (IOException ioe) {
			log.error("Output File creation failed");
			throw new SplunkExceptions("Output File Creation Failed ...", ioe);
		}
		log.info("Output file population in progress ...");
		try {
			
			writer = new FileWriter(outputFile);
			/*writer.append(MonitoringConstants.ATTRIBUTES+"\n");*//** truncated */
			writer.append(props.getAttributes()+"\n");
			
			for(int i = 0; i < monitorBuilderList.size(); i++) {
				writer.append(monitorBuilderList.get(i).getAppName()+","
								+monitorBuilderList.get(i).getUrl()+","
								+monitorBuilderList.get(i).getStatus()+","
								+monitorBuilderList.get(i).getResponseCode()+","
								+monitorBuilderList.get(i).getResponseTime()+","
								+monitorBuilderList.get(i).getResponseMessage()+","
								+((monitorBuilderList.get(i).getCertExpiryDate()!=null)?
										monitorBuilderList.get(i).getCertExpiryDate():"N/A"
								)+","
								+monitorBuilderList.get(i).getLastChecked()+","
								+((monitorBuilderList.get(i).getSslVersion()!=null)?
										monitorBuilderList.get(i).getSslVersion():"N/A")+"\n");
			}
			writer.flush();			
			log.info("Output file populated successfully.");
			writer.close();
		} catch(IOException e) {
			
			log.error("File writing failed (Probable cause: Output file open in edit mode) ...");
			throw new SplunkExceptions("File Writing Failed, halting execution ..."
					+"\nPlease close the file, if it is open.", e);
		}
		
		return true;
	}

}
