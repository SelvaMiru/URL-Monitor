/**
 * 
 */
package com.accenture.splunk.exceptions;

/**
 * Custom Exception class for URL-SSL Monitoring, inherits RuntimeException.
 * Exception defined to contain Exceptions, generated as a result for execution of UrlSslMonitoring class.
 * @author sayon.kumar.ghosh
 *
 */
public class SplunkExceptions extends RuntimeException {

	/** generated serial version ID for SplunkExceptions */
	private static final long serialVersionUID = -6723331431642959323L;
	
	/**
	 *  default constructor for SplunkExceptions
	 */
	public SplunkExceptions() {
		super();		
	}
	
	/**
	 * SplunkException(String) for single message, no cause of Throwable type
	 * @param message
	 */
	public SplunkExceptions(String message) {
		super(message);
	}
	
	/**
	 * SplunkExceptions(Throwable) for only cause of Exception, no message of String type
	 * @param cause
	 */
	public SplunkExceptions(Throwable cause) {
		super(cause);
	}
	
	/**
	 * SplunkExcpetions(String, Throwable) for both exception message and the cause
	 * @param message
	 * @param cause
	 */
	public SplunkExceptions(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	public SplunkExceptions(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	

}
