package com.accenture.splunk.urlmonitor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;

public class PropertiesStorage {
	
	private final static Logger log = LoggerFactory.getLogger(PropertiesStorage.class);
	
	protected static PropertiesBuilder setProperties(String arg) throws SplunkExceptions {
		
		String hostname = null;
		String system = null;
		Properties properties = null;
		FileInputStream fis = null;
		int connectTimeoutThreshold = MonitoringConstants.CONNECTION_TIMEOUT_THRESHOLD;
		int readTimeoutThreshold = MonitoringConstants.READ_TIMEOUT_THRESHOLD;
		String inputFileLocation = null;
		String outputFileLocation = null;
		String pathToLog4jProps = null;
		String attributes = MonitoringConstants.ATTRIBUTES;
		String simpleDateFormat = MonitoringConstants.SIMPLE_DATE_FORMAT;
		PropertiesBuilder propsData = null;
		
		try {
			
			properties = new Properties();
			fis = new FileInputStream(arg);
			properties.load(fis);
			system = System.getProperty("os.name");
			system = system.split(" ")[0].toLowerCase();
			hostname = InetAddress.getLocalHost().getHostName();
			pathToLog4jProps = properties.getProperty("urlssl.pathToLog4jProps."+system+"."+hostname);			
			PropertyConfigurator.configure(pathToLog4jProps);			
			log.info("Properties Loaded Successfully.");			
			log.info("System OS:: {}.", system);			
			log.info("Hostname determined:: {}.", hostname);
			log.info("Path to Log4j.properties:: {}", pathToLog4jProps);
			inputFileLocation = properties.getProperty("urlssl.inputFileLocation."+system+"."+hostname);
			log.info("Input File Location:: {}", inputFileLocation);
			outputFileLocation = properties.getProperty("urlssl.outputFileLocation."+system+"."+hostname);
			log.info("Output File Location:: {}", outputFileLocation);
			pathToLog4jProps = properties.getProperty("urlssl.pathToLog4jProps."+system+"."+hostname);
			log.info("Path to Log4j.properties:: {}", pathToLog4jProps);
			attributes = properties.getProperty("urlssl.attributes");
			log.info("Headers:: {}.", attributes);
			simpleDateFormat = properties.getProperty("urlssl.simpleDateFormat");
			log.info("Date Format:: {}.", simpleDateFormat);
			connectTimeoutThreshold = Integer.parseInt(properties.getProperty("urlssl.connectionTimeoutThreshold"));
			log.info("Connection Timeout Threshold:: {} milli-seconds", connectTimeoutThreshold);
			readTimeoutThreshold = Integer.parseInt(properties.getProperty("urlssl.readTimeoutThreshold"));
			log.info("Read Timeout Threshold:: {} milli-seconds", readTimeoutThreshold);
			
			propsData = new PropertiesBuilder.Builder()
						.setConnectTimeoutThreshold(connectTimeoutThreshold)
						.setReadTimeoutThreshold(readTimeoutThreshold)
						.setInputFileLocation(inputFileLocation)
						.setOutputFileLocation(outputFileLocation)
						.setPathToLog4jProps(pathToLog4jProps)
						.setAttributes(attributes)
						.setSimpleDateFormat(simpleDateFormat)
						.setSystem(system)
						.setHostName(hostname)
						.build();
			
			log.info("Properties have been build.");
			
		} catch (UnknownHostException e) {
			throw new SplunkExceptions("Host not Found", e);
		} catch (FileNotFoundException e) {
			throw new SplunkExceptions("URLSSL.Properties file not Found", e);
		} catch (IOException e) {
			throw new SplunkExceptions(e);
		}
		
		return propsData;
		
	}	

}
