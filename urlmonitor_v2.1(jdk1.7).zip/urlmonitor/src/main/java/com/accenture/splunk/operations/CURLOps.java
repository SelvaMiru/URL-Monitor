package com.accenture.splunk.operations;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.PropertiesBuilder;

public class CURLOps {

	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(CURLOps.class);

	/**
	 * Function to retry connection to any URL, after initial connection failure<br/>
	 * or on connection timeout.
	 * 
	 * @param url (URL)
	 * @return (String array)
	 */
	protected String[] retryConnectionWithCURL(URL url, PropertiesBuilder props) {

		String[] outputs = null;
		Process process = null;
		Scanner scanner = null;
		/**
		 * commandUnix = curl -Iks -w
		 * "| RESPONSE_CODE: %{http_code}\nRESPONSE_TIME: %{time_total}\n" {} |
		 * egrep 'HTTP|RESPONSE',url
		 */
		String[] commandUnixCURL = {
				"/bin/sh",
				"-c",
				"curl -Iks -w \"| RESPONSE_CODE: %{http_code}\\n"
						+ "RESPONSE_TIME: %{time_total}\\n\" \"" + url
						+ "\" | egrep 'HTTP|RESPONSE'" };
		@SuppressWarnings("unused")
		String[] commandWindowsCURL = { "ping " + url };
		try {
			if (props.getSystem().equalsIgnoreCase("sunos")
					|| props.getSystem().equalsIgnoreCase("linux")) {

				process = Runtime.getRuntime().exec(commandUnixCURL);
				scanner = new Scanner(process.getInputStream());
				String temp = "";

				while (scanner.hasNext()) {
					temp = temp + scanner.nextLine() + " ";
				}
				outputs = temp.split(" ");

				if (outputs.length > 5) {
					String tmp = outputs[2];
					for (int i = 3; !outputs[i].equalsIgnoreCase("|"); i++) {
						tmp += " " + outputs[i];
					}
					outputs[2] = tmp;
				}
				scanner.close();

			} else if (props.getSystem().equalsIgnoreCase("windows")) {
				/* process = Runtime.getRuntime().exec(commandWindows); */
				// scoped for later release ...
			} else
				;

		} catch (IOException ioe) {			
			log.error(
					"Connection attempt failed for URL: {} with exception: {}",
					url.toString(), ioe.getMessage());
		}
		return outputs;

	}

}
