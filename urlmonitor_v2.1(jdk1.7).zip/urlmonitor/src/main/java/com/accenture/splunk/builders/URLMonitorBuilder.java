package com.accenture.splunk.builders;

import java.net.URL;
import java.security.cert.Certificate;
/**
 * Builder class for output fields, i.e.,<br/>
 * 	1.	Application Name,<br/>
 * 	2.	URL,<br/>
 * 	3.	Status,<br/>
 * 	4.	Response Code,<br/>
 * 	5.	Response Time,<br/>
 * 	6.	Response Message,<br/>
 * 	7.	Certificate Expiry Date and<br/>
 * 	8.	Last Checked<br/>
 *  9.  SSL Version<br/>
 * @author sayon.kumar.ghosh
 *
 */
public class URLMonitorBuilder {
	
	/** stores the Application Name of the URL*/
	String appName;
	
	/** for storing the Response Code from the URL */
	int responseCode;
	
	/** for storing the Response Time for the URL */
	long responseTime;
	
	/** for storing the Response Message retrieved from the URL */
	String responseMessage;
	
	/** stores the URL for the Application Website*/
	URL url;
	
	/** contains the Certificate Excpiry Date of the site for the Application */
	String certExpiryDate;
	
	/** contains the details of the site Certificate */
	Certificate[] certDetails;
	
	/** for storing the status of the Website, i.e., "UP" or "DOWN" */
	String status;
	
	/** stores the time when the Website was last pinged */
	String lastChecked;
	
	/** stores the SSL version */
	String sslVersion;
	/**
	 * contructor for UrlSslMonitoringBuilder class, taking in Builder object values as parameter
	 * @param builder
	 */
	public URLMonitorBuilder(Builder builder) {
		this.appName = builder.appName;
		this.responseCode = builder.responseCode;
		this.responseTime = builder.responseTime;
		this.responseMessage = builder.responseMessage;
		this.url = builder.url;
		this.status = builder.status;
		this.certExpiryDate = builder.certExpiryDate;
		this.certDetails = builder.certDetails;
		this.lastChecked = builder.lastChecked;
		this.sslVersion = builder.sslVersion;
	}
	
	/**
	 * getter function for Application Name
	 * @return appName (String)
	 */
	public String getAppName() {
		return appName;
	}
	
	/**
	 * getter function for Response Code
	 * @return responseCode (int)
	 */
	public int getResponseCode() {
		return responseCode;
	}
	
	/**
	 * getter function for Response Time
	 * @return responseTime (long)
	 */
	public long getResponseTime() {
		return responseTime;
	}
	
	/**
	 * getter function for Response Message
	 * @return responseMessage (String)
	 */
	public String getResponseMessage() {
		return responseMessage;
	}

	/**
	 * getter function for URL for the Application Website
	 * @return url (URL)
	 */
	public URL getUrl() {
		return url;
	}

	/**
	 * getter function for the Certificate Expiry Date for the Application Website
	 * @return certExpiryDate (String)
	 */
	public String getCertExpiryDate() {
		return certExpiryDate;
	}

	/**
	 * getter function for Certificate Details for the Application Website URL
	 * @return certDetails (Certificate[])
	 */
	public Certificate[] getCertDetails() {
		return certDetails;
	}
	
	/**
	 * getter function for Status of the Application Website
	 * @return status (String)
	 */
	public String getStatus() {
		return status;
	}
	
	/** 
	 * getter function for Last Checked for the URL
	 * @return lastChecked (String)
	 */
	public String getLastChecked() {
		return lastChecked;
	}
	
	/**
	 * getter function for SSL version
	 * @return sslVersion (String)
	 */
	public String getSslVersion() {
		return sslVersion;
	}

	/**
	 * setter function for Application Name
	 * @param appName (String)
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * setter function for Response Code
	 * @param responseCode (int)
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * setter function for Response Time 
	 * @param responseTime (long)
	 */
	public void setResponseTime(long responseTime) {
		this.responseTime = responseTime;
	}

	/**
	 * setter function for Response Message
	 * @param responseMessage (String)
	 */
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	/**
	 * setter function for URL
	 * @param url (URL)
	 */
	public void setUrl(URL url) {
		this.url = url;
	}

	/**
	 * setter function for Certificate Expiry Date
	 * @param certExpiryDate (String)
	 */
	public void setCertExpiryDate(String certExpiryDate) {
		this.certExpiryDate = certExpiryDate;
	}

	/**
	 * setter function for Certificate Details
	 * @param certDetails (Certificate[])
	 */
	public void setCertDetails(Certificate[] certDetails) {
		this.certDetails = certDetails;
	}
	
	/**
	 * setter function for Status
	 * @param status (String)
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * setter function for Last Checked
	 * @param lastChecked (String)
	 */
	public void setLastChecked(String lastChecked) {
		this.lastChecked = lastChecked;
	}
	
	/**
	 * setter function for SSL version
	 * @param sslVersion
	 */
	public void setSslVersion(String sslVersion) {
		this.sslVersion = sslVersion;
	}
	
	/**
	 * overriden toString() function for UrlSslMonitoringBuilder class
	 * @return (String)
	 */
	@Override
	public String toString() {
		return " {"
				+" appName= "+getAppName()
				+", responseCode= "+getResponseCode()
				+", responseTime= "+getResponseTime()
				+", responseMessage= "+getResponseMessage()
				+", url= "+getUrl()
				+", status= "+getStatus()
				+", certExpiryDate= "+getCertExpiryDate()
				+", certDetails= "+getCertDetails()
				+", lastChecked= "+getLastChecked()
				+", sslVersion= "+getSslVersion()
				+" } ";
	}

	/**
	 * Builder inner class for UrlSslMonitoringBuilder, to facilitate the setter functions for UrlSslMonitoringBuilder 
	 * variables and build method, follows Builder Design Pattern
	 * @author sayon.kumar.ghosh
	 *
	 */
	public static class Builder {
		
		/** stores the Application Name for the Application */
		private String appName;
		
		/** stores the Response Code for the Application URL */
		private int responseCode;
		
		/** stores the Response Time for the Application URL */
		private long responseTime;
		
		/** stores the Response Message for the Application URL */
		private String responseMessage;
		
		/** stores the URL of the Application Website */
		private URL url;
		
		/** stores the Certificate Expiry Date for the Application Website */
		private String certExpiryDate;
		
		/** stores the Certificate Details for the Application Website Certificate */
		private Certificate[] certDetails;
		
		/** stores the Website Status for the Application Website */
		private String status;
		
		/** stores the time in which the URL was last pinged */
		private String lastChecked;
		
		/** stores the SSL version of the Certificate*/
		private String sslVersion;
		
		/**
		 * setter function for Application Name
		 * @param appName
		 * @return (Builder object)
		 */
		public Builder setAppName(String appName) {
			this.appName = appName;
			return this;			
		}
		
		/**
		 * setter function for Response Code for Application Website;
		 * <br/>located in UrlSslMonitoringBuilder$Builder class
		 * @param responseCode
		 * @return (Builder object)
		 */
		public Builder setResponseCode(int responseCode) {
			this.responseCode = responseCode;
			return this;
		}
		
		/** 
		 * setter function for Response Time for Application Website;
		 * <br/>located in UrlSslMonitoringBuilder$Builder class
		 * @param responseTime
		 * @return (Builder object)
		 */
		public Builder setResponseTime(long responseTime) {
			this.responseTime = responseTime;
			return this;
		}
		
		/**
		 * setter function for Response Message for Application Website;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param responseMessage
		 * @return (Builder object)
		 */
		public Builder setResponseMessage(String responseMessage) {
			this.responseMessage = responseMessage;
			return this;
		}
		
		/**
		 * setter function for URL for Application Website;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param url
		 * @return (Builder object)
		 */
		public Builder setUrl(URL url) {
			this.url = url;
			return this;
		}
		
		/**
		 * setter function Certificate Expiry Date for Application Website;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param certExpiryDate
		 * @return (Builder object)
		 */
		public Builder setCertExpiryDate(String certExpiryDate) {
			this.certExpiryDate = certExpiryDate;
			return this;
		}
		
		/**
		 * setter function for Certificate Details for Application Website Certificate;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param certDetails
		 * @return (Builder object)
		 */
		public Builder setCertDetails(Certificate[] certDetails) {
			this.certDetails = certDetails;
			return this;
		}
		
		/**
		 * setter function for Status of the URL for the Application;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param status
		 * @return (Builder object)
		 */
		public Builder setStatus(String status) {
			this.status = status;
			return this;
		}
		
		/**
		 * setter function for Last Checked (time for URL ping) for the Application Website;
		 * <br/>located in InputDataBuilder$Builder class
		 * @param lastChecked
		 * @return (Builder object)
		 */
		public Builder setLastChecked(String lastChecked) {
			this.lastChecked = lastChecked;
			return this;
		}
		
		/**
		 * setter function for SSL version of the site Certificate;
		 * @param sslVersion
		 * @return (Builder object)
		 */
		public Builder setSslVersion(String sslVersion) {
			this.sslVersion = sslVersion;
			return this;
		}
		
		/**
		 * build() method for Builder inner class of UrlSslMonitoringBuilder class, for building the objects of 
		 * UrlSslMonitoringBuilder, i.e., Application Name, URL, Status, Response Code, Response Time, Response Message,
		 * Certificate Expiry Date, Certificate Details and Last Checked
		 * @return (UrlSslMonitoringBuilder object)
		 */
		public URLMonitorBuilder build() {
			return new URLMonitorBuilder(this);
		}
		
		/**
		 * Overridden toString() method for UrlSslMonitoringBuilder$Builder class
		 * @return (String)
		 */
		@Override
		public String toString() {
			return " {"
					+" appName= "+this.appName
					+", responseCode= "+this.responseCode
					+", responseTime= "+this.responseTime
					+", responseMessage= "+this.responseMessage
					+", url= "+this.url
					+", status= "+this.status
					+", certExpiryDate= "+this.certExpiryDate
					+", certDetails= "+this.certDetails
					+", lastChecked= "+this.lastChecked
					+", sslVersion= "+this.sslVersion
					+" }";
		}
		
	}

}
