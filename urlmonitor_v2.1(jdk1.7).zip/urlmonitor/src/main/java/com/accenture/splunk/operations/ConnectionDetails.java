package com.accenture.splunk.operations;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.splunk.builders.InputDataBuilder;
import com.accenture.splunk.builders.PropertiesBuilder;
import com.accenture.splunk.builders.URLMonitorBuilder;
import com.accenture.splunk.exceptions.SplunkExceptions;

public class ConnectionDetails {
	
	/** {@link Logger} object */
	private final static Logger log = LoggerFactory.getLogger(ConnectionDetails.class);
	
	/** Global variable declaration */
	private long startTime;
	private HttpsURLConnection httpsConnection;
	private HttpURLConnection httpConnection;
	private URL url;
	private String appName;
	private int connectTimeout;
	private int readTimeout;
	private int responseCode;
	private long responseTime;
	private String responseMessage;
	private String sslExpiryDate;
	private String sslVersion;
	private Certificate[] certificate;
	private boolean status;
	private Calendar cal;
	private MiscellaneousOps miscOps;
	private WGETOps wgetOps;
	private CURLOps curlOps;
	private SimpleDateFormat sdf;
	private String lastChecked;
	private String[] outputs;
	private PropertiesBuilder props;	
	
	/**
	 * Pings the URL for every Application URL and updates the supported data in an 
	 * <br/>{@link URLMonitorBuilder} object which in turn is used to 
	 * <br/>generate the output (.csv) file.
	 * @param inputData (an {@link InputDataBuilder} object)
	 * @return {@link URLMonitorBuilder} object
	 * @throws SplunkExceptions
	 */
	public URLMonitorBuilder checkUrlSsl(InputDataBuilder inputData,
			PropertiesBuilder props) throws SplunkExceptions {
		
		/** Global variable initialiazation section */
		this.props = props;
		startTime = 0;		
		url = inputData.getUrl();
		appName = inputData.getAppName();
		connectTimeout = this.props.getConnectTimeoutThreshold();
		readTimeout = this.props.getReadTimeoutThreshold();
		responseCode = 0;
		responseTime = 0;
		responseMessage = null;
		sslExpiryDate = null;
		sslVersion = null;
		certificate = null;
		status = false; 
		cal = Calendar.getInstance();
		miscOps = new MiscellaneousOps();
		wgetOps = new WGETOps();
		curlOps = new CURLOps();
		sdf = new SimpleDateFormat(this.props.getSimpleDateFormat());
        lastChecked = sdf.format(cal.getTime());
        outputs = null;
        
        /** Local variable declaration and initialization section */
        boolean firstAttemptSuccessful = false;
        boolean secondAttemptSuccessful = false;
        boolean thirdAttemptSuccessful = false;
        
        
        /** Using inbuilt java functionalities for 1st Attempt */
        
        log.info("1st attempt for URL: {}", url.toString());		
		firstAttemptSuccessful = firstAttempt();		
		if(firstAttemptSuccessful) {
			log.info("Successfully connected (1st Attempt) to {}", url.toString());
			log.info("Response Recorded: {}, URL: {} with Expiry: {}", appName, url, sslExpiryDate);
		} else {
			
			/** Using WGET Command for 2nd Attempt */
			
			log.info("2nd attempt for URL: {}", url.toString());
			secondAttemptSuccessful = secondAttempt();
			if(secondAttemptSuccessful) {				
				log.info("Successfully connected (2nd Attempt) to {}", url.toString());
				log.info("Response Recorded: {}, URL: {} with Expiry: {}", appName, url, sslExpiryDate);
			} else {
				
				/** Using CURL Command for 3rd Attempt */
				
				log.error("Reconnection attempt unsuccessful to {}", url.toString());
				log.warn("3rd and final attempt for URL: {}", url.toString());
				thirdAttemptSuccessful = thirdAttempt();
				if(thirdAttemptSuccessful) {
					log.info("Successfully connected (3rd Attempt) to {}", url.toString());
					log.info("Response Recorded: {}, URL: {} with Expiry: {}", appName, url, sslExpiryDate);
				} else {
					log.error("Re-reconnection attempt unsuccessful to {}", url.toString());
					log.warn("No more attempts remain for {}, considered DOWN", url.toString());
				}
				
			}
		}
		
		return miscOps.buildMonitor(appName, url, responseCode, responseMessage, responseTime, certificate, sslExpiryDate,
				status? "UP":"DOWN", lastChecked, sslVersion);			
	}
	
	/**
	 * Method containing inbuilt java functionalities for 1st Attempt
	 * @return <b>boolean</b> object
	 */
	private boolean firstAttempt() {
		try {
			if(url.getProtocol().equalsIgnoreCase("https")) {
				httpsConnection = (HttpsURLConnection)url.openConnection();				
				httpsConnection.setConnectTimeout(connectTimeout);
				httpsConnection.setReadTimeout(readTimeout);
				httpsConnection.setRequestMethod("HEAD");
				startTime = System.currentTimeMillis();
				responseCode = httpsConnection.getResponseCode();
				responseMessage = httpsConnection.getResponseMessage();
				status = miscOps.getUrlStatus(responseCode);
				if(status) {
					httpsConnection.connect();
					httpsConnection.getInputStream();
					responseTime = System.currentTimeMillis() - startTime;
					certificate = miscOps.getCertificate(url);
					sslExpiryDate = sdf.format(((X509Certificate)certificate[0]).getNotAfter());
					sslVersion = ((X509Certificate)certificate[0]).getVersion()+"";
				} else {
					responseTime = System.currentTimeMillis() - startTime;
					certificate = null;
					sslExpiryDate = null;
					sslVersion = null;
				}
			} else {
				httpConnection = (HttpURLConnection)url.openConnection();
				httpConnection.setConnectTimeout(connectTimeout);
				httpConnection.setReadTimeout(readTimeout);
				httpConnection.setRequestMethod("HEAD");
				startTime = System.currentTimeMillis();
				responseCode = httpConnection.getResponseCode();
				responseMessage = httpConnection.getResponseMessage();
				status = miscOps.getUrlStatus(responseCode);
				if(status) {
					httpConnection.connect();
					httpConnection.getInputStream();
				}
				responseTime = System.currentTimeMillis() - startTime;					
				sslExpiryDate = null;
				certificate = null;
				sslVersion = null;
			}
			
		} catch (SSLPeerUnverifiedException | ProtocolException exception) {			
			log.error("Exception: {} for {}, URL: {}", exception.getMessage(), appName, url);
			responseMessage = (responseMessage!=null)? responseMessage: miscOps.getMessage(exception.getMessage());
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			
		} catch (IOException ioe) {			
			log.error("Exception: {} for {}, URL: {}", ioe.getMessage(), appName, url);
			responseMessage = (responseMessage!=null)? responseMessage: miscOps.getMessage(ioe.getMessage());
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			
		}
		return status;
	}
	
	/**
	 * Method containing WGET Command for 2nd Attempt
	 * @return <b>boolean</b> object
	 */
	private boolean secondAttempt() {
		
		try {
			outputs = wgetOps.retryConnectionWithWGET(miscOps.formatUrl(url), props);
			if(outputs != null) {
				if(outputs.length > 2) {
					responseCode = Integer.parseInt(outputs[1]);
					responseTime = (long) (Double.parseDouble(outputs[2]) * 1000);
					responseMessage = outputs[3];
					status = miscOps.getUrlStatus(responseCode);
				}
				certificate = null;
				sslExpiryDate = null;
				sslVersion = null;
				lastChecked = sdf.format(cal.getTime());
			}							
		} catch (MalformedURLException mue) {
			log.error("Error in formatted URL: {}, Exception: {}", mue.getMessage(), mue);
			throw new SplunkExceptions("Error in Formatted URL: "+url, mue);
		} catch (StringIndexOutOfBoundsException sioobe) {
			log.error("Error in formatting URL: {}", sioobe.getMessage());
			throw new SplunkExceptions("Error in Formatting URL: "+url, sioobe);
		}
		return status;				
	}
	
	/**
	 * Method containing CURL Command for 3rd Attempt
	 * @return <b>boolean</b> object
	 */
	private boolean thirdAttempt() {
		
		try {			
			outputs = curlOps.retryConnectionWithCURL(miscOps.formatUrl(url), props);
			if(outputs != null) {
				if(outputs.length > 5 && outputs[1].matches("[-+]?\\d*\\.?\\d+")) {
					responseCode = Integer.parseInt(outputs[1]);
					responseMessage = outputs[2];
					status = miscOps.getUrlStatus(responseCode);
					if(outputs[outputs.length - 1].matches("[-+]?\\d*\\.?\\d+")) {
						responseTime = (long) (Double.parseDouble(outputs[outputs.length - 1])*1000);
					} else {
						responseTime = 0L;
					}					
				}
			} 
			certificate = null;
			sslExpiryDate = null;
			sslVersion = null;
			lastChecked = sdf.format(cal.getTime());
		} catch (StringIndexOutOfBoundsException | NumberFormatException
				| MalformedURLException exceptions) {
			log.error("Error in formatted URL: {}, Exception: {}", exceptions.getMessage(), exceptions);
			throw new SplunkExceptions("Error in Formatted URL: "+url, exceptions);
		}
		return status;
	}
}